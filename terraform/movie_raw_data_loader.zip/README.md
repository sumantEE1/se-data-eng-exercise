* Create python virtual environment for your project
   ```python3 -m venv .venv```
   it will create .venv
* Activate virtual environment
   ```source .venv/bin/activate```
   